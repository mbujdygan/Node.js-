'use strict';
const { Store } = require('./store');
const { createApp, seedAdmin } = require('./app');

const store = new Store({ file: process.env.DATA_FILE || null });
seedAdmin(store);
const port = process.env.PORT || 3000;
createApp(store).listen(port, () => {
  console.log(`Kindergarten API listening on http://localhost:${port}`);
});
